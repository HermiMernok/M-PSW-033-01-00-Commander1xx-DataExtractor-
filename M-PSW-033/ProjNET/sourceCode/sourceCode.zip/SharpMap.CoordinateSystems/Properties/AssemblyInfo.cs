using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Proj.NET")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Proj.NET")]
[assembly: AssemblyCopyright("Copyright � 2009")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: System.CLSCompliant(true)]
[assembly: ComVisible(false)]
[assembly: Guid("e16f3ac5-214b-4ef3-9809-740a13cf0ec7")]
[assembly: AssemblyVersion("1.2.*")]
[assembly: AssemblyFileVersion("1.2.0.0")]
