### Frequently Asked Questions

* [Introduction to Coordinate Systems](http://www.sharpgis.net/2007/05/05/SpatialReferencesCoordinateSystemsProjectionsDatumsEllipsoidsConfusing.aspx)
* [Constructing a Coordinate System (CS) by Well-known Text (WKT)](CreateCSByWKT)
* [Loading a projection by Spatial Reference ID (SRID)](LoadByID)
* [Constructing a Coordinate System by code](CreateCSByCode)
* [Projecting points from one Coordinate System to another](CreateProjection)