**.NET Spatial Reference and Projection Engine**
Proj.NET performs point-to-point coordinate conversions between geodetic coordinate systems for use in fx. Geographic Information Systems (GIS) or GPS applications. The spatial reference model used adheres to the [Simple Features specification](http://www.opengeospatial.org/standards/sfo).

* [Read the FAQ](FAQ) for common questions.
* [Popular Well-Known Text representations for Spatial Reference Systems](CommonWellKnownText)

**Supports**:
* Datum transformations
* Geographic, Geocentric, and Projected coordinate systems
* Compatible with both Microsoft .NET 2.0, [Mono](http://www.mono-project.com), .NET Compact Framework & [Silverlight](Silverlight)
* Converts coordinate systems to/from [Well-Known Text](Well-Known-Text) (WKT) and to XML

**Projection types currently supported**:
* Mercator
* Transverse Mercator
* Albers
* Lambert Conformal
* Krovak
See [Supported projections](Supported-projections) for details.

**Nuget**:
There's also a package available in the Nuget Gallery, created by Mathieu Cartoixa [Proj.NET 1.2](https://nuget.org/packages/ProjNet)

**Resources**:
For an introduction to spatial reference systems [see here](http://www.sharpgis.net/2007/05/05/SpatialReferencesCoordinateSystemsProjectionsDatumsEllipsoidsConfusing.aspx)

If you're working with Google/Bing/OpenLayers, maybe this blog post can help you: [The Google Maps / Bing Maps Spherical Mercator Projection](http://alastaira.wordpress.com/2011/01/23/the-google-maps-bing-maps-spherical-mercator-projection)

{silverlight:url=http://silverlight.sharpgis.net/ClientBin/ProjNet.Silverlight.TestApplication.xap,height=400,width=800}