### Compiling for Silverlight

Silverlight gives you the option of having .NET code running inside the browser as part of a client page, without the need for serverside code. Proj.NET gives you the power of fast on-the-fly reprojection directly inside the browser without the need of calling back to a serverside reprojection engine. This literally gives you the option of doing millions of point-to-point projections directly in a webbrowser!

Proj.NET has been prepared for compilation with Silverlight, but you need to go through a few steps to get this to work.

# Install Visual Studio codename Orcas/2007 [Get it here](http://go.microsoft.com/fwlink/?LinkID=89146&clcid=0x409)
# Install Microsoft Silverlight Tools Alpha for Visual Studio codename "Orcas" Beta 1 [Get it here](http://go.microsoft.com/fwlink/?LinkID=89149&clcid=0x409)
# Start Orcas and Create a new "Silverlight Class Library" project
# Remove the generated class file (Class1.cs) from the project.
# Copy all the .cs files from Proj.NET to the project (You can easily do this by dragging the file folders to the project).
# Right-click the project and select "Properties". Go to the Build tab and enter "Silverligt" in "Conditional compilation symbols".

You should now be able to compile this library and reference it into your silverlight application.
