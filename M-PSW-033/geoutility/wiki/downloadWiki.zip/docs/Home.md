**Project Description**
GeoUtility library is a tool supporting complex mathematical calculations in geographical coordinate systems like Latitude/Longitude, UTM, MGRS, etc.  It can be used for desktop/web development in CLI implementations like .NET, MONO. Supported map services: Google Maps, Virtual Earth, Yahoo Maps.
But, GeoUtility Library is more than a simple coordinate conversion library. Unlike other similar libraries it can calculate and download satellite images from several providers for given coordinates and zoom levels. Switching from one satellite image provider to another is only one line of code. Developers do not have to care about technical details. In advance the library also provides many calculations on these satellite images.

![Main demo application](Home_demoapp.png)  ![GeoUtility Library Mobile on a smart device](Home_geoutility_smart_device.png) Screenshot demo applications.

## [Need support for your software projects? Hire us!](http://www.codeplex.com/site/users/contact/geoutility?OriginalUrl=http%3a%2f%2fgeoutility.codeplex.com)

### Examples:


**Transforming Latitude/Longitude to UTM:**
{code:c#}
using GeoUtility.GeoSystem;
Geographic geo = new Geographic(8.12345, 50.56789);
UTM utm = (UTM)geo;
double east = utm.East;
double north = utm.North;
int zone = utm.Zone;
string band = utm.Band;
{code:c#}

**Transforming UTM to Gauss-Krueger:**
{code:c#}
using GeoUtility.GeoSystem;
UTM utm = new UTM(32, "U", 412345, 5567890);
GaussKrueger gauss = (GaussKrueger)utm;
double east = gauss.East;
double north = gauss.North;
{code:c#}

**Transforming Gauss-Krueger to MGRS/UTMRef:**
{code:c#}
using GeoUtility.GeoSystem;
GaussKrueger gauss = new GaussKrueger(3456789, 5612345);
MGRS mgrs = (MGRS)gauss;
double east = mgrs.East;
double north = mgrs.North;
int zone = mgrs.Zone;
string band = mgrs.Band;
string grid = mgrs.Grid;
{code:c#}

**Transforming MGRS/UTMRef to Latitude/Longitude:**
{code:c#}
using GeoUtility.GeoSystem;
MGRS mgrs = new MGRS(32, "U", "MA", 12345, 67890);
Geographic geo = (Geographic)mgrs;
double lon = geo.Longitude;
double lat = geo.Latitude;
{code:c#}

**Transforming Gauss-Krueger to Google Earth satellite image:**
{code:c#}
using GeoUtility.GeoSystem;
GaussKrueger gauss = new GaussKrueger(3456789, 5612345);
MapService maps = (MapService)gauss;
maps.MapServer = MapService.Info.MapServer.GoogleMaps;
maps.Zoom = 18;
Image image = maps.Image.Load(); 
{code:c#}

**Moving Yahoo Maps satellite image in north-western direction:**
{code:c#}
using GeoUtility.GeoSystem;
Geographic geo = new Geographic(8.12345, 50.56789);
MapService.Info.MapServer server = MapService.Info.MapServer.YahooMaps;
MapService map = new MapService(geo, server);
GeoUtility.GeoSystem.MapService.Info.MapServiceTileBase tile;
tile = map.Move(MapService.Info.MapDirection.Northwest, 1, false);
string output = tile.URL;
{code:c#}

**Calculate a satellite image (Bing Maps / Microsoft Virtual Earth) that contains two different coordinates on it:**
{code:c#}
using GeoUtility.GeoSystem;
Geographic geo = new Geographic(13.377829, 52.515934);   // Berlin Brandenburg Gate
Geographic geo2 = new Geographic(13.376026, 52.518597);  // Berlin Reichstag
MapService map = new MapService(geo);
MapService.Info.MapServiceVirtualEarthMapsTile tile;                
tile = map.CalculateCommonTile(geo2, MapService.Info.MapServer.VirtualEarth);
Image image = new MapService(tile).Image.Load();         // new MapService-object from tile and load image
string output = tile.URL;                                // or retrieve a url to the satellite image
{code:c#}

_Copyright 2008-2010 Steffen Habermehl_